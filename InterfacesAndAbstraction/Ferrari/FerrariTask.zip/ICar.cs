﻿public interface ICar
{
    string DriverName { get; set; }
    string ThrotlePush();
    string BreakPush();
}
