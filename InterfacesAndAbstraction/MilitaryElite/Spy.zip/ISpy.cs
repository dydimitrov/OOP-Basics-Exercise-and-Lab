﻿using System;
using System.Collections.Generic;
using System.Text;

public interface ISpy
{
    int CodeNumber { get; set; }
}
