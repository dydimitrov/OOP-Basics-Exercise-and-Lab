﻿using System;
using System.Collections.Generic;
using System.Text;

public interface IEngineer
{
    HashSet<Repair> SetOfRepairs { get; set; }
}
