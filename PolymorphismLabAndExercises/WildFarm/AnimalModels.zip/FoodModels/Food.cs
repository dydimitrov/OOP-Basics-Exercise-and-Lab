﻿using System;
using System.Collections.Generic;
using System.Text;

public abstract class Food
{
    public virtual int Quantity { get; set; }
}
